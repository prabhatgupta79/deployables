Attached is the relevant code file modified based on TLS / SSL authentication according to requirements, please update to UAT environment for verification.
1、File：express.properties:
   （1）Path：D:\rikingApp\apache-tomcat-9.0.16\fbds1.2\src\net\config\express.properties
   （2）Add content：Add the following two configuration items to the configuration file, And modify the SSL_PATH path according to the actual situation.
	#SSL证书路径
		SSL_PATH=/riking/Truststore.jks
		SSL_PWD=jssecacerts
2、File：LoginAction.class、LoginAction$1.class：Replace the original
	（1）Path：D:\rikingApp\apache-tomcat-9.0.16\fbds1.2\src\net\riking\system\action
	（2）Add ‘javax.net.ssl.trustStore’ to the LDAP context.
